
import numpy as np
from DataLoad.DataLoad import SetSplit, LoadNirtest
from Preprocessing.Preprocessing import Preprocessing
from WaveSelect.WaveSelcet import SpctrumFeatureSelcet
from Clustering.Cluster import Cluster
from Regression.Rgs import QuantitativeAnalysis
from Plot.plot import nirplot_assign
from sklearn.model_selection import GridSearchCV
import hpelm

# 光谱定量分析
def SpectralQuantitativeAnalysis(data, label, ProcessMethods, FslecetedMethods, SetSplitMethods, model,EPOCH,acti,c_num,loss,optim):

    """
    :param data: shape (n_samples, n_features), 光谱数据
    :param label: shape (n_samples, ), 光谱数据对应的标签(理化性质)
    :param ProcessMethods: string, 预处理的方法, 具体可以看预处理模块
    :param FslecetedMethods: string, 光谱波长筛选的方法, 提供UVE、SPA、Lars、Cars、Pca
    :param SetSplitMethods : string, 划分数据集的方法, 提供随机划分、KS划分、SPXY划分
    :param model : string, 定量分析模型, 包括ANN、PLS、SVR、ELM、CNN、SAE等，后续会不断补充完整
    :return: Rmse: float, Rmse回归误差评估指标
             R2: float, 回归拟合,
             Mae: float, Mae回归误差评估指标
    """
    # nirplot_assign(data,600,1898,2)
    ProcesedData = Preprocessing(ProcessMethods, data)
    FeatrueData, labels = SpctrumFeatureSelcet(FslecetedMethods, ProcesedData, label)
    X_train, X_test, y_train, y_test = SetSplit(SetSplitMethods, FeatrueData, labels, test_size=0.2, randomseed=123)
    Rmse, R2, Mae = QuantitativeAnalysis(model, X_train, X_test, y_train, y_test,EPOCH,acti,c_num,loss,optim)

    return Rmse, R2, Mae

if __name__ == '__main__':

    ## 载入原始数据并可视化
    data2, label2 = LoadNirtest('Rgs')
    #plotspc(data2, "raw specturm")
    # 光谱定量分析演示
    # 示意1: 预处理算法:MSC , 波长筛选算法: Uve, 数据集划分:KS, 定性分量模型: SVR
    #这里我改了参数，10,'relu',5,'MSE','Adam'，10 是epoch，relu是激活函数，可以选。5是CNN有5层，MSE是损失函数，Adam是优化，这些可以到CNN.p文件看一下有什么选择。
    # RMSE1=[]
    # R21=[]
    # MAE1=[]
    # opti=['Adam','SGD','Adagrad','Adadelta','RMSprop','Adamax','LBFGS']
    # loss=['MSE','L1','CrossEntropy','Poisson','KLDiv']
    # for i in range(0,4):
    RMSE, R2, MAE = SpectralQuantitativeAnalysis(data2, label2, "MMS", "None", "random", "CNN_vgg",300,'relu',5,'MSE','Adam')
        # RMSE1=np.append(RMSE1,RMSE)
        # R21=np.append(R21,R2)
        # MAE1=np.append(MAE1,MAE)
    print("The RMSE:{} R2:{}, MAE:{} of result!".format(RMSE, R2, MAE))
        # print(RMSE1)
        # print(R21)
        # print(MAE1)


    # ## 光谱预处理并可视化
    # method = "SNV"
    # Preprocessingdata = Preprocessing(method, data)
    # plotspc(Preprocessingdata, method)
    # ## 波长特征筛选并可视化
    # method = 'Uve'
    # SpectruSelected, y = SpctrumFeatureSelcet(method, data, label)
    # print("全光谱数据维度")
    # print(len(data[0,:]))
    # print("经过{}波长筛选后的数据维度".format(method))
    # print(len(SpectruSelected[0, :]))
    # # #划分数据集
    # X_train, X_test, y_train, y_test = SetSplit('spxy', SpectruSelected, y, 0.2, 123)




